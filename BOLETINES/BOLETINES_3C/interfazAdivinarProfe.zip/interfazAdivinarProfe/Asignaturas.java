package extra.interfazAdivinarProfe;

public enum Asignaturas {
	
	PROGRAMACION,
	BASES_DE_DATOS,
	LENGUAJE_DE_MARCAS,
	SISTEMAS,
	INGLES_REFUERZO,
	ENTORNOS,
	FOL

}
