package extra.interfazAdivinarProfe;

public enum Comunidad {
	
	MADRID,
	GALICIA
	
}
