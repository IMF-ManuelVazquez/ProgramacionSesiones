package extra.interfazAdivinarProfe;

public enum Profesores {

	MANUEL_VAZQUEZ,
	ANTONIO_OTERO,
	BORJA,
	JAVIER_CARCELES,
	PILAR_LOPEZ;
	
}
