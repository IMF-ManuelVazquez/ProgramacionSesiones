package extra.interfazAdivinarProfe;

public enum Sexo {
	HOMBRE,
	MUJER;
}
